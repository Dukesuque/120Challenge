# Guía de Implementación - WorkTime

Esta guía proporciona instrucciones para implementar las funcionalidades reales de backend, API y Firebase en la aplicación WorkTime.

## 📋 Tabla de Contenidos

1. [Configuración de Firebase](#configuración-de-firebase)
2. [Implementación de API REST](#implementación-de-api-rest)
3. [Persistencia de datos local](#persistencia-de-datos-local)
4. [Autenticación real](#autenticación-real)
5. [Notificaciones push](#notificaciones-push)

---

## 🔥 Configuración de Firebase

### Paso 1: Crear proyecto en Firebase

1. Ir a [Firebase Console](https://console.firebase.google.com/)
2. Crear un nuevo proyecto
3. Agregar aplicación Android/iOS

### Paso 2: Instalar dependencias

Agregar al `pubspec.yaml`:

```yaml
dependencies:
  firebase_core: ^2.24.2
  firebase_auth: ^4.16.0
  cloud_firestore: ^4.14.0
  firebase_messaging: ^14.7.10
```

### Paso 3: Configurar Firebase en la app

Descargar `google-services.json` (Android) y `GoogleService-Info.plist` (iOS) y colocarlos en:
- Android: `android/app/google-services.json`
- iOS: `ios/Runner/GoogleService-Info.plist`

### Paso 4: Inicializar Firebase

En `lib/main.dart`:

```dart
import 'package:firebase_core/firebase_core.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const WorkTimeApp());
}
```

### Paso 5: Implementar FirebaseService

Editar `lib/services/firebase_service.dart`:

```dart
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class FirebaseService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Implementar métodos reales aquí
  Future<UserCredential> signInWithEmailAndPassword(
    String email,
    String password,
  ) async {
    return await _auth.signInWithEmailAndPassword(
      email: email,
      password: password,
    );
  }

  // ... más métodos
}
```

---

## 🌐 Implementación de API REST

### Paso 1: Instalar dependencias

Agregar al `pubspec.yaml`:

```yaml
dependencies:
  http: ^1.1.2
  dio: ^5.4.0  # Alternativa más completa
```

### Paso 2: Configurar base URL

En `lib/services/api_service.dart`, reemplazar:

```dart
static const String baseUrl = 'https://tu-api.com/api/v1';
```

### Paso 3: Implementar métodos reales

```dart
import 'package:http/http.dart' as http;
import 'dart:convert';

class ApiService {
  static const String baseUrl = 'https://tu-api.com/api/v1';
  String? _token;

  Future<Map<String, dynamic>> login(String email, String password) async {
    final response = await http.post(
      Uri.parse('$baseUrl/auth/login'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode({
        'email': email,
        'password': password,
      }),
    );

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      _token = data['token'];
      return data;
    } else {
      throw Exception('Error en login');
    }
  }

  Future<Map<String, dynamic>> getUserProfile(String userId) async {
    final response = await http.get(
      Uri.parse('$baseUrl/users/$userId'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $_token',
      },
    );

    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception('Error al obtener perfil');
    }
  }

  // Implementar resto de métodos...
}
```

---

## 💾 Persistencia de datos local

### Paso 1: Instalar dependencias

Agregar al `pubspec.yaml`:

```yaml
dependencies:
  shared_preferences: ^2.2.2  # Para datos simples
  sqflite: ^2.3.0  # Para base de datos local
  hive: ^2.2.3  # Alternativa rápida
```

### Paso 2: Implementar almacenamiento local

Crear `lib/services/storage_service.dart`:

```dart
import 'package:shared_preferences/shared_preferences.dart';

class StorageService {
  static final StorageService _instance = StorageService._internal();
  factory StorageService() => _instance;
  StorageService._internal();

  late SharedPreferences _prefs;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  Future<void> saveToken(String token) async {
    await _prefs.setString('token', token);
  }

  String? getToken() {
    return _prefs.getString('token');
  }

  Future<void> saveUser(Map<String, dynamic> user) async {
    await _prefs.setString('user', json.encode(user));
  }

  Map<String, dynamic>? getUser() {
    final userStr = _prefs.getString('user');
    if (userStr != null) {
      return json.decode(userStr);
    }
    return null;
  }

  Future<void> clear() async {
    await _prefs.clear();
  }
}
```

---

## 🔐 Autenticación real

### Paso 1: Implementar login real

En `lib/presentation/screens/login/login_screen.dart`:

```dart
Future<void> _handleLogin() async {
  if (_formKey.currentState?.validate() ?? false) {
    setState(() => _isLoading = true);

    try {
      // Opción 1: Con Firebase
      final userCredential = await FirebaseService().signInWithEmailAndPassword(
        _emailController.text,
        _passwordController.text,
      );

      // Opción 2: Con API REST
      final response = await ApiService().login(
        _emailController.text,
        _passwordController.text,
      );

      // Guardar token
      await StorageService().saveToken(response['token']);

      if (mounted) {
        context.go('/home');
      }
    } catch (e) {
      // Mostrar error
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }
}
```

### Paso 2: Verificar sesión al inicio

En `lib/presentation/screens/splash/splash_screen.dart`:

```dart
@override
void initState() {
  super.initState();
  _checkAuth();
}

Future<void> _checkAuth() async {
  await Future.delayed(const Duration(seconds: 2));

  final token = StorageService().getToken();
  
  if (mounted) {
    if (token != null) {
      context.go('/home');
    } else {
      context.go('/login');
    }
  }
}
```

---

## 📱 Notificaciones push

### Paso 1: Configurar Firebase Messaging

En `lib/services/firebase_service.dart`:

```dart
import 'package:firebase_messaging/firebase_messaging.dart';

class FirebaseService {
  final FirebaseMessaging _messaging = FirebaseMessaging.instance;

  Future<void> initNotifications() async {
    // Solicitar permisos
    await _messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );

    // Obtener token
    final token = await _messaging.getToken();
    print('FCM Token: $token');

    // Escuchar mensajes en foreground
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      print('Mensaje recibido: ${message.notification?.title}');
      // Mostrar notificación local
    });

    // Manejar tap en notificación
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      print('Notificación abierta: ${message.data}');
      // Navegar a pantalla específica
    });
  }
}
```

---

## 🔄 Gestión de estado avanzada

### Opción 1: Provider (ya incluido)

Crear `lib/state/app_state.dart`:

```dart
import 'package:flutter/material.dart';
import '../models/user_model.dart';

class AppState extends ChangeNotifier {
  UserModel? _user;
  bool _isAuthenticated = false;

  UserModel? get user => _user;
  bool get isAuthenticated => _isAuthenticated;

  void setUser(UserModel user) {
    _user = user;
    _isAuthenticated = true;
    notifyListeners();
  }

  void logout() {
    _user = null;
    _isAuthenticated = false;
    notifyListeners();
  }
}
```

Envolver la app en `lib/app.dart`:

```dart
import 'package:provider/provider.dart';

class WorkTimeApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => AppState(),
      child: MaterialApp.router(
        // ...
      ),
    );
  }
}
```

### Opción 2: Riverpod (recomendado para proyectos grandes)

Agregar dependencia:

```yaml
dependencies:
  flutter_riverpod: ^2.4.9
```

---

## 📊 Sincronización de datos

### Implementar sincronización periódica

Crear `lib/services/sync_service.dart`:

```dart
import 'dart:async';

class SyncService {
  Timer? _syncTimer;

  void startSync() {
    _syncTimer = Timer.periodic(
      const Duration(minutes: 5),
      (timer) async {
        await _syncData();
      },
    );
  }

  Future<void> _syncData() async {
    try {
      // Sincronizar actividades
      final activities = await ApiService().getActivities(
        userId: 'current_user_id',
        date: DateTime.now(),
      );

      // Guardar en local
      // ...

      // Sincronizar resumen
      // ...
    } catch (e) {
      print('Error en sincronización: $e');
    }
  }

  void stopSync() {
    _syncTimer?.cancel();
  }
}
```

---

## 🧪 Testing

### Agregar dependencias de testing

```yaml
dev_dependencies:
  mockito: ^5.4.4
  flutter_test:
    sdk: flutter
```

### Crear tests unitarios

Crear `test/services/api_service_test.dart`:

```dart
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';

void main() {
  group('ApiService', () {
    test('login should return token', () async {
      // Arrange
      final apiService = ApiService();

      // Act
      final result = await apiService.login('test@test.com', 'password');

      // Assert
      expect(result['token'], isNotNull);
    });
  });
}
```

---

## 📝 Checklist de implementación

- [ ] Configurar Firebase
- [ ] Implementar autenticación real
- [ ] Conectar con API REST
- [ ] Implementar persistencia local
- [ ] Configurar notificaciones push
- [ ] Implementar sincronización de datos
- [ ] Agregar manejo de errores robusto
- [ ] Implementar tests unitarios
- [ ] Implementar tests de integración
- [ ] Configurar CI/CD
- [ ] Preparar para producción

---

## 🚀 Despliegue

### Android

1. Configurar firma de app en `android/app/build.gradle`
2. Generar keystore
3. Compilar release: `flutter build apk --release`
4. Subir a Google Play Console

### iOS

1. Configurar certificados en Xcode
2. Compilar release: `flutter build ios --release`
3. Subir a App Store Connect

---

## 📚 Recursos adicionales

- [Documentación de Flutter](https://docs.flutter.dev/)
- [Firebase para Flutter](https://firebase.flutter.dev/)
- [Guía de arquitectura Flutter](https://docs.flutter.dev/development/data-and-backend/state-mgmt)
- [Best practices Flutter](https://docs.flutter.dev/perf/best-practices)

---

**Nota**: Esta guía es un punto de partida. Adaptar según las necesidades específicas del proyecto y los requisitos del backend.
