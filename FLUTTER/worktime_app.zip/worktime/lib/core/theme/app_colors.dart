import 'package:flutter/material.dart';

/// Colores de la aplicación WorkTime
/// Basados en el diseño de Figma con modo oscuro
class AppColors {
  // Colores de fondo
  static const Color backgroundPrimary = Color(0xFF000000);
  static const Color backgroundSecondary = Color(0xFF1A1A1A);
  static const Color backgroundCard = Color(0xFF2A2A2A);

  // Color primario
  static const Color primary = Color(0xFF00A3FF);
  static const Color primaryDark = Color(0xFF0082CC);
  static const Color primaryLight = Color(0xFF33B5FF);

  // Colores de estado
  static const Color success = Color(0xFF00C853);
  static const Color warning = Color(0xFFFF9800);
  static const Color error = Color(0xFFF44336);
  static const Color info = Color(0xFF2196F3);

  // Colores de texto
  static const Color textPrimary = Color(0xFFFFFFFF);
  static const Color textSecondary = Color(0xFFB0B0B0);
  static const Color textTertiary = Color(0xFF808080);

  // Colores de borde
  static const Color border = Color(0xFF3A3A3A);
  static const Color borderLight = Color(0xFF4A4A4A);

  // Colores de overlay
  static const Color overlay = Color(0x80000000);
  static const Color overlayLight = Color(0x40000000);

  // Colores de iconos
  static const Color iconPrimary = Color(0xFFFFFFFF);
  static const Color iconSecondary = Color(0xFFB0B0B0);
  static const Color iconAccent = Color(0xFF00A3FF);

  // Colores de gráficas
  static const Color chartPrimary = Color(0xFF00A3FF);
  static const Color chartSecondary = Color(0xFF00C853);
  static const Color chartTertiary = Color(0xFFFF9800);
  static const Color chartQuaternary = Color(0xFFF44336);
}
