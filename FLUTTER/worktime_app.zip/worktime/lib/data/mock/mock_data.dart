import '../../models/user_model.dart';
import '../../models/activity_model.dart';
import '../../models/summary_model.dart';

/// Datos mock para desarrollo
/// Simula datos que vendrían de una API o base de datos
class MockData {
  // Usuario mock
  static final UserModel mockUser = UserModel(
    id: '1',
    name: 'Juan Pérez',
    email: 'juan.perez@worktime.com',
    position: 'Desarrollador Senior',
    age: 32,
    phone: '+34 600 123 456',
    department: 'Desarrollo',
    startDate: DateTime(2020, 3, 15),
  );

  // Actividades del día mock
  static List<ActivityModel> getMockActivities() {
    final today = DateTime.now();
    return [
      ActivityModel(
        id: '1',
        userId: '1',
        type: ActivityType.clockIn,
        timestamp: DateTime(today.year, today.month, today.day, 9, 0),
        description: 'Entrada',
        location: 'Oficina Central',
      ),
      ActivityModel(
        id: '2',
        userId: '1',
        type: ActivityType.breakStart,
        timestamp: DateTime(today.year, today.month, today.day, 11, 30),
        description: 'Inicio pausa',
        location: 'Oficina Central',
      ),
      ActivityModel(
        id: '3',
        userId: '1',
        type: ActivityType.breakEnd,
        timestamp: DateTime(today.year, today.month, today.day, 12, 0),
        description: 'Fin pausa',
        location: 'Oficina Central',
      ),
      ActivityModel(
        id: '4',
        userId: '1',
        type: ActivityType.meeting,
        timestamp: DateTime(today.year, today.month, today.day, 15, 0),
        description: 'Reunión de equipo',
        location: 'Sala de reuniones A',
        notes: 'Planificación sprint',
      ),
    ];
  }

  // Resumen mensual mock
  static SummaryModel getMockMonthlySummary() {
    final now = DateTime.now();
    final daysInMonth = DateTime(now.year, now.month + 1, 0).day;
    
    // Generar resúmenes diarios
    final dailySummaries = <DailySummary>[];
    for (int i = 1; i <= daysInMonth; i++) {
      final date = DateTime(now.year, now.month, i);
      
      // Determinar estado del día
      DayStatus status;
      double hours;
      
      if (i <= now.day) {
        // Días pasados
        if (date.weekday == DateTime.saturday || date.weekday == DateTime.sunday) {
          status = DayStatus.absence;
          hours = 0;
        } else if (i % 5 == 0) {
          status = DayStatus.incomplete;
          hours = 6.5;
        } else {
          status = DayStatus.complete;
          hours = 8.0;
        }
      } else {
        // Días futuros
        status = DayStatus.pending;
        hours = 0;
      }
      
      dailySummaries.add(DailySummary(
        date: date,
        hours: hours,
        status: status,
      ));
    }
    
    // Calcular totales
    final totalHours = dailySummaries
        .where((d) => d.status != DayStatus.pending)
        .fold<double>(0.0, (sum, d) => sum + d.hours);
    
    final workDays = dailySummaries
        .where((d) => d.date.weekday != DateTime.saturday && 
                     d.date.weekday != DateTime.sunday &&
                     d.date.isBefore(now.add(const Duration(days: 1))))
        .length.toDouble();
    
    final expectedHours = workDays * 8.0;
    final extraHours = totalHours > expectedHours ? totalHours - expectedHours : 0.0;
    final pendingHours = expectedHours > totalHours ? expectedHours - totalHours : 0.0;
    
    return SummaryModel(
      userId: '1',
      month: now.month,
      year: now.year,
      totalHours: totalHours,
      expectedHours: expectedHours,
      extraHours: extraHours,
      pendingHours: pendingHours,
      dailySummaries: dailySummaries,
    );
  }

  // Reuniones del día mock
  static List<Map<String, dynamic>> getMockMeetings() {
    return [
      {
        'id': '1',
        'title': 'Daily Standup',
        'time': '09:30',
        'duration': '15 min',
        'location': 'Sala Virtual',
        'attendees': 8,
      },
      {
        'id': '2',
        'title': 'Revisión de código',
        'time': '11:00',
        'duration': '1 hora',
        'location': 'Sala A',
        'attendees': 4,
      },
      {
        'id': '3',
        'title': 'Planificación Sprint',
        'time': '15:00',
        'duration': '2 horas',
        'location': 'Sala B',
        'attendees': 12,
      },
    ];
  }

  // Notificaciones mock
  static List<Map<String, dynamic>> getMockNotifications() {
    return [
      {
        'id': '1',
        'title': 'Recordatorio',
        'message': 'No olvides fichar tu salida',
        'time': 'Hace 1 hora',
        'read': false,
      },
      {
        'id': '2',
        'title': 'Aprobación',
        'message': 'Tu solicitud de vacaciones ha sido aprobada',
        'time': 'Hace 3 horas',
        'read': false,
      },
      {
        'id': '3',
        'title': 'Actualización',
        'message': 'Nueva versión de la app disponible',
        'time': 'Ayer',
        'read': true,
      },
    ];
  }

  // Horario laboral mock
  static Map<String, dynamic> getMockWorkSchedule() {
    return {
      'weeklyHours': 40,
      'dailyHours': 8,
      'startTime': '09:00',
      'endTime': '18:00',
      'breakTime': '1 hora',
      'workDays': ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes'],
    };
  }

  // Vacaciones mock
  static Map<String, dynamic> getMockVacations() {
    return {
      'totalDays': 22,
      'usedDays': 8,
      'remainingDays': 14,
      'pendingRequests': 1,
      'upcomingVacations': [
        {
          'startDate': '15/03/2026',
          'endDate': '19/03/2026',
          'days': 5,
          'status': 'Aprobado',
        },
      ],
    };
  }

  // Ausencias mock
  static List<Map<String, dynamic>> getMockAbsences() {
    return [
      {
        'id': '1',
        'date': '05/02/2026',
        'type': 'Enfermedad',
        'status': 'Justificada',
        'notes': 'Certificado médico adjunto',
      },
      {
        'id': '2',
        'date': '28/01/2026',
        'type': 'Personal',
        'status': 'Aprobada',
        'notes': 'Trámite personal',
      },
    ];
  }
}
